package $PACKAGE$.domain.user;

import com.github.linyuzai.domain.core.DomainIdGenerator;

/**
 * 用户 id 生成器
 */
public interface UserIdGenerator extends DomainIdGenerator<Object> {
}

package $PACKAGE$.domain.user;

import com.github.linyuzai.domain.core.DomainRepository;

/**
 * 用户存储
 */
public interface UserRepository extends DomainRepository<User, Users> {

}

package $PACKAGE$.domain.user;

import com.github.linyuzai.domain.core.DomainCollection;

/**
 * 用户集合
 */
public interface Users extends DomainCollection<User> {
}

package $PACKAGE$.domain.sample;

import com.github.linyuzai.domain.core.DomainCollection;

/**
 * 示例集合
 */
public interface Samples extends DomainCollection<Sample> {
}

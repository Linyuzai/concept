package $PACKAGE$.domain.sample;

import com.github.linyuzai.domain.core.DomainRepository;

/**
 * 示例存储
 */
public interface SampleRepository extends DomainRepository<Sample, Samples> {
}

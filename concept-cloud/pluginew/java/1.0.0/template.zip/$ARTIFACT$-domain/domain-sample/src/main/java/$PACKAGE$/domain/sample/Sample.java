package $PACKAGE$.domain.sample;

import $PACKAGE$.domain.user.User;
import $PACKAGE$.domain.user.Users;
import com.github.linyuzai.domain.core.DomainEntity;

/**
 * 示例
 */
public interface Sample extends DomainEntity {

    String getSample();

    User getUser();

    Users getUsers();
}

package $PACKAGE$.rpc;

import lombok.Data;

/**
 * 条件远程对象
 */
@Data
public class ConditionsRO {

}

package $PACKAGE$.basic;

import org.springframework.context.annotation.Configuration;

/**
 * 基础配置
 */
@Configuration
public class $CLASS$BasicConfiguration {
}

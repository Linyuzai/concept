package $PACKAGE$.basic.boot;

import org.springframework.context.annotation.Configuration;

/**
 * 基础配置
 */
@Configuration
public class $CLASS$BasicConfiguration {
}

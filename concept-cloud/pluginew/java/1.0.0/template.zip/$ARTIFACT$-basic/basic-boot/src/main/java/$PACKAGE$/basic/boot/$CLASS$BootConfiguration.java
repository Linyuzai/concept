package $PACKAGE$.basic.boot;

import org.springframework.context.annotation.Configuration;

/**
 * 单体应用配置
 */
@Configuration
public class $CLASS$BootConfiguration {
}

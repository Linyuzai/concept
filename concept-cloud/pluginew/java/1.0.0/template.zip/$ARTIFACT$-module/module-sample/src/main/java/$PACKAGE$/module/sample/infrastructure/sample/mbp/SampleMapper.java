package $PACKAGE$.module.sample.infrastructure.sample.mbp;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

interface SampleMapper extends BaseMapper<SamplePO> {
}

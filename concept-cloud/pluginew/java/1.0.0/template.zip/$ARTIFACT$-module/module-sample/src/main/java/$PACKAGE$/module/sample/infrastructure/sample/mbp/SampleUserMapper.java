package $PACKAGE$.module.sample.infrastructure.sample.mbp;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface SampleUserMapper extends BaseMapper<SampleUserPO> {
}

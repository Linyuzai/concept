package $PACKAGE$.module.user.infrastructure.user.mbp;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface UserMapper extends BaseMapper<UserPO> {
}

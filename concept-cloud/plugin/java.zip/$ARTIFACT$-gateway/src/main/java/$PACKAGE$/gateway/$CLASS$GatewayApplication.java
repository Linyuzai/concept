package $PACKAGE$.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class $CLASS$GatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run($CLASS$GatewayApplication.class, args);
    }
}

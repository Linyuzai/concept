package $PACKAGE$.basic;

import org.springframework.context.annotation.Configuration;

/**
 * 这里添加单体应用需要而微服务不需要注入的组件
 */
@Configuration
public class $CLASS$BootConfiguration {
}

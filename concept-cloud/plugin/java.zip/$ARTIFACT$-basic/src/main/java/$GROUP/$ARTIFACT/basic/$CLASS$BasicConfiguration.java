package $PACKAGE$.basic;

import org.springframework.context.annotation.Configuration;

/**
 * 单体应用和微服务都需要注入的组件
 */
@Configuration
public class $CLASS$BasicConfiguration {

}

package $PACKAGE$.sample.domain.user;

public interface User {

    String getId();

    String getName();
}

package $PACKAGE$.sample.domain.xxx;

import org.springframework.stereotype.Service;

@Service
public class DeviceService {

}

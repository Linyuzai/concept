package $PACKAGE$.sample.domain.xxx;

import org.springframework.stereotype.Service;

/**
 * 相同业务所有组件建议放在同一个包中，方便查找
 */
@Service
public class XXXService {

}

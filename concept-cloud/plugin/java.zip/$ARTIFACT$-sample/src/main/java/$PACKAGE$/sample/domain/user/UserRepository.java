package $PACKAGE$.sample.domain.user;

public interface UserRepository {

    User get(String id);
}

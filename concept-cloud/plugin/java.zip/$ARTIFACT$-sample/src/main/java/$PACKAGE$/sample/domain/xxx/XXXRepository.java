package $PACKAGE$.sample.domain.xxx;

public interface XXXRepository {

}

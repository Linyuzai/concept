package $PACKAGE$.sample.domain.xxx;

/**
 * 相同业务所有组件建议放在同一个包中，方便查找
 */
public interface XXXRepository {

}

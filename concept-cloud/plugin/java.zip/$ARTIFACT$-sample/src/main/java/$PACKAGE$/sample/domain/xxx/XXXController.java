package $PACKAGE$.sample.domain.xxx;

import org.springframework.web.bind.annotation.*;

/**
 * 相同业务所有组件建议放在同一个包中，方便查找
 */
@RestController
@RequestMapping("/xxx")
public class XXXController {

}

package $PACKAGE$.sample.domain.xxx;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/xxx")
public class XXXController {

}

package $PACKAGE$.user.domain.user;

public interface User {

    String getId();

    String getName();
}
